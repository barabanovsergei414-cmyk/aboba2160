package dev.realweather.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.NativeImage;
import dev.realweather.RealWeather;
import dev.realweather.cm1.Cm1Manager;
import dev.realweather.cm1.Cm1Window;
import dev.realweather.config.ClientConfig;
import dev.realweather.config.Quality;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Рисует настоящее поле CM1 (облачная и дождевая вода) как объёмные облака. Данные окна упакованы в 2D-атлас
 * из горизонтальных срезов (R = sqrt(облако), G = sqrt(дождь), B = апдрафт), шейдер интерполирует их трилинейно.
 */
public final class Cm1Renderer {
    static ShaderInstance shader;
    private static DynamicTexture tex;
    private static int texW, texH, tilesX;
    private static long uploadedVersion = -1;
    private static final ResourceLocation TEX_LOC = ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, "cm1_atlas");

    private Cm1Renderer() {}

    private static void upload(Cm1Window w) {
        tilesX = (int) Math.ceil(Math.sqrt(w.nz));
        int tilesY = (w.nz + tilesX - 1) / tilesX;
        int width = tilesX * w.nx, height = tilesY * w.ny;
        if (tex == null || width != texW || height != texH) {
            if (tex != null) tex.close();
            tex = new DynamicTexture(new NativeImage(NativeImage.Format.RGBA, width, height, true));
            tex.setFilter(true, false);
            Minecraft.getInstance().getTextureManager().register(TEX_LOC, tex);
            texW = width;
            texH = height;
            uploadedVersion = -1;
        }
        if (w.version == uploadedVersion) return;
        NativeImage px = tex.getPixels();
        if (px == null) return;
        for (int k = 0; k < w.nz; k++) {
            int tx = k % tilesX, ty = k / tilesX;
            for (int j = 0; j < w.ny; j++) {
                for (int i = 0; i < w.nx; i++) {
                    int idx = (k * w.ny + j) * w.nx + i;
                    int r = (int) (Math.sqrt(Mth.clamp(w.cloud[idx] / 0.004f, 0f, 1f)) * 255f);
                    int g = (int) (Math.sqrt(Mth.clamp(w.rain[idx] / 0.006f, 0f, 1f)) * 255f);
                    int b = (int) (Mth.clamp(w.w[idx] / 30f, 0f, 1f) * 255f);
                    px.setPixelRGBA(tx * w.nx + i, ty * w.ny + j, 0xFF000000 | (b << 16) | (g << 8) | r);
                }
            }
        }
        tex.upload();
        uploadedVersion = w.version;
    }

    static void draw(RenderLevelStageEvent e, ClientLevel level) {
        Cm1Window w = Cm1Manager.current();
        if (shader == null || w == null || w.mapping() == null) return;
        Minecraft mc = Minecraft.getInstance();
        upload(w);
        if (tex == null) return;
        Vec3 cp = e.getCamera().getPosition();
        float pt = e.getPartialTick().getGameTimeDeltaPartialTick(false);
        double now = level.getGameTime() + pt;
        Quality q = ClientConfig.QUALITY.get();
        SkyModel m = SkyModel.INSTANCE;
        m.update(level, pt, cp.x, cp.z, now);
        float sq = ClientConfig.STEP_QUALITY.get().floatValue();
        float auto = StormRenderer.autoScale;
        float maxDist = (float) Math.min(q.maxDist * 1.5f, ClientConfig.VIEW_DISTANCE.get());

        ShaderInstance s = shader;
        var inv = s.getUniform("InvViewProj");
        if (inv != null) inv.set(StormRenderer.invViewProj(e));
        StormRenderer.set3(s, "CamPos", (float) cp.x, (float) cp.y, (float) cp.z);
        StormRenderer.set1(s, "Time", (float) (now / 20.0));
        StormRenderer.set3(s, "SunDir", m.sunDir);
        StormRenderer.set3(s, "SunColor", m.sunColor);
        StormRenderer.set3(s, "AmbientColor", m.ambient);
        StormRenderer.set3(s, "HazeColor", m.horizon);
        StormRenderer.set1(s, "Steps", q.steps * sq * auto);
        StormRenderer.set1(s, "StepScale", q.stepScale / (sq * auto));
        StormRenderer.set1(s, "MaxDist", maxDist);
        StormRenderer.set1(s, "Density", ClientConfig.CLOUD_DENSITY.get().floatValue());
        StormRenderer.set1(s, "Contrast", ClientConfig.CONTRAST.get().floatValue());
        StormRenderer.set1(s, "Realism", ClientConfig.REALISM.get().floatValue());
        StormRenderer.set1(s, "FlashAmt", ClientStorms.flashAmount(now));
        StormRenderer.set3(s, "FlashPos", (float) (ClientStorms.flashX() - cp.x), (float) ClientStorms.flashY(),
                (float) (ClientStorms.flashZ() - cp.z));
        StormRenderer.set1(s, "Darkness", m.darkness);
        StormRenderer.set3(s, "WinMin", (float) (w.minX() - cp.x), (float) w.minY(), (float) (w.minZ() - cp.z));
        StormRenderer.set3(s, "WinSize", (float) (w.maxX() - w.minX()), (float) (w.maxY() - w.minY()), (float) (w.maxZ() - w.minZ()));
        StormRenderer.set4(s, "Grid", w.nx, w.ny, w.nz, tilesX);
        StormRenderer.set2(s, "AtlasSize", texW, texH);
        s.setSampler("DepthSampler", mc.getMainRenderTarget().getDepthTextureId());
        s.setSampler("Atlas", tex.getId());

        StormRenderer.beginPass(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShader(() -> s);
        StormRenderer.fullscreenQuad();
        StormRenderer.endPass();
    }
}
