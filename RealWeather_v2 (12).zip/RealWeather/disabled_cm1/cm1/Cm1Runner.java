package dev.realweather.cm1;

import dev.realweather.RealWeather;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Запуск внешней программы CM1 (команда и папка берутся ТОЛЬКО из конфига). Вывод пишется в лог. */
public final class Cm1Runner {
    private static volatile Process process;
    private static volatile String lastLine = "";

    private Cm1Runner() {}

    public static boolean isRunning() {
        Process p = process;
        return p != null && p.isAlive();
    }

    public static String lastLine() { return lastLine; }

    /** Разбор командной строки с кавычками. */
    static List<String> tokenize(String cmd) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQ = false;
        for (int i = 0; i < cmd.length(); i++) {
            char c = cmd.charAt(i);
            if (c == '"') inQ = !inQ;
            else if (Character.isWhitespace(c) && !inQ) {
                if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
            } else cur.append(c);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    public static synchronized void start(String command, String workDir) throws IOException {
        if (isRunning()) throw new IOException("CM1 уже запущен");
        List<String> cmd = tokenize(command);
        if (cmd.isEmpty()) throw new IOException("В конфиге пуста команда запуска CM1 (cm1.command)");
        File dir = new File(workDir.isEmpty() ? "." : workDir);
        if (!dir.isDirectory()) throw new IOException("Рабочая папка CM1 не найдена: " + dir.getAbsolutePath());
        RealWeather.LOGGER.info("[CM1] запуск: {} (папка {})", cmd, dir.getAbsolutePath());
        ProcessBuilder pb = new ProcessBuilder(cmd).directory(dir).redirectErrorStream(true);
        Process p = pb.start();
        process = p;
        Thread t = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    lastLine = line;
                    RealWeather.LOGGER.info("[CM1] {}", line);
                }
            } catch (IOException ignored) {
            }
            try {
                RealWeather.LOGGER.info("[CM1] процесс завершён, код {}", p.waitFor());
            } catch (InterruptedException ignored) {
            }
        }, "RealWeather-CM1-output");
        t.setDaemon(true);
        t.start();
    }

    public static synchronized void stop() {
        Process p = process;
        if (p == null) return;
        p.destroy();
        try {
            if (!p.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)) p.destroyForcibly();
        } catch (InterruptedException ignored) {
            p.destroyForcibly();
        }
        process = null;
    }
}
