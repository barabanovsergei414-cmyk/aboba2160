package dev.realweather.client;

import dev.realweather.RealWeather;
import dev.realweather.client.radar.RadarScreen;
import dev.realweather.config.ClientConfig;
import dev.realweather.config.Quality;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.common.ModConfigSpec;

/** Экран настроек RealWeather: вкладки, слайдеры, переключатели, пресеты. Все изменения применяются сразу и сохраняются в конфиг. */
public class SettingsScreen extends Screen {
    private static final String[] TABS = {"Графика", "Небо и облака", "Шторм и торнадо", "Радар и прочее"};
    private static final String[] TAB_HINTS = {
            "Качество и скорость. Если мало FPS — «Лёгкий» или автокачество.",
            "Вид неба, облаков и теней. Выбор типа облаков — «Вид облаков».",
            "Штормовые облака, воронка торнадо, обломки.",
            "Радар (клавиша K) и полный список параметров."};
    private static final String[] REGIMES = {"по дням (авто)", "ясно", "кучевые малые", "кучевые мощные", "слоисто-кучевые", "слоистые",
            "высококучевые", "высокослоистые", "перистые", "перистослоистые", "перисто-кучевые", "линзовидные", "смешанный",
            "пасмурно", "обычные облака", "башенные кучевые"};
    private static final int ACCENT = 0xFF4FB3FF;

    private final Screen parent;
    private int tab = 0;
    private int px, py, pw, ph;

    public SettingsScreen(Screen parent) {
        super(Component.literal("RealWeather"));
        this.parent = parent;
    }

    // ------------------------------------------------------------------ виджеты

    private static final class DoubleSlider extends AbstractSliderButton {
        private final String label, fmt;
        private final ModConfigSpec.DoubleValue cfg;
        private final double min, max;

        DoubleSlider(int x, int y, int w, String label, ModConfigSpec.DoubleValue cfg, double min, double max, String fmt) {
            super(x, y, w, 20, Component.empty(), (cfg.get() - min) / (max - min));
            this.label = label; this.cfg = cfg; this.min = min; this.max = max; this.fmt = fmt;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label + ": " + String.format(fmt, min + value * (max - min))));
        }

        @Override
        protected void applyValue() {
            cfg.set(min + value * (max - min));
            cfg.save();
        }
    }

    private static final class IntSlider extends AbstractSliderButton {
        private final String label;
        private final ModConfigSpec.IntValue cfg;
        private final int min, max;
        private final String[] names;

        IntSlider(int x, int y, int w, String label, ModConfigSpec.IntValue cfg, int min, int max, String[] names) {
            super(x, y, w, 20, Component.empty(), (double) (cfg.get() - min) / (max - min));
            this.label = label; this.cfg = cfg; this.min = min; this.max = max; this.names = names;
            updateMessage();
        }

        private int current() {
            return min + (int) Math.round(value * (max - min));
        }

        @Override
        protected void updateMessage() {
            int v = current();
            setMessage(Component.literal(label + ": " + (names != null ? names[v - min] : String.valueOf(v))));
        }

        @Override
        protected void applyValue() {
            cfg.set(current());
            cfg.save();
        }
    }

    private CycleButton<Boolean> toggle(int x, int y, int w, String label, ModConfigSpec.BooleanValue cfg) {
        return CycleButton.onOffBuilder(cfg.get()).create(x, y, w, 20, Component.literal(label), (b, v) -> {
            cfg.set(v);
            cfg.save();
        });
    }

    private void rebuild() {
        clearWidgets();
        init();
    }

    // ------------------------------------------------------------------ пресеты

    private void preset(int kind) {
        switch (kind) {
            case 0 -> {                                   // Лёгкий
                ClientConfig.QUALITY.set(Quality.LOW);
                ClientConfig.STEP_QUALITY.set(0.7);
                ClientConfig.DETAIL.set(-1);
                ClientConfig.CLOUD_SHADOWS.set(false);
                ClientConfig.REALISM.set(0.2);
                ClientConfig.VIEW_DISTANCE.set(3000.0);
            }
            case 1 -> {                                   // Баланс
                ClientConfig.QUALITY.set(Quality.MEDIUM);
                ClientConfig.STEP_QUALITY.set(1.0);
                ClientConfig.DETAIL.set(0);
                ClientConfig.CLOUD_SHADOWS.set(true);
                ClientConfig.REALISM.set(0.35);
                ClientConfig.VIEW_DISTANCE.set(4500.0);
            }
            default -> {                                  // Красивый
                ClientConfig.QUALITY.set(Quality.HIGH);
                ClientConfig.STEP_QUALITY.set(1.4);
                ClientConfig.DETAIL.set(1);
                ClientConfig.CLOUD_SHADOWS.set(true);
                ClientConfig.REALISM.set(0.6);
                ClientConfig.VIEW_DISTANCE.set(6500.0);
            }
        }
        ClientConfig.AUTO_QUALITY.set(true);
        ClientConfig.AUTO_QUALITY.save();
        rebuild();
    }

    // ------------------------------------------------------------------ раскладка

    @Override
    protected void init() {
        pw = Math.min(width - 24, 620);
        ph = Math.min(height - 24, 340);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        int cx = px + 152, cw = pw - 166;
        int colW = (cw - 8) / 2;
        int c0 = cx, c1 = cx + colW + 8;
        int y0 = py + 62, row = 26;

        for (int i = 0; i < TABS.length; i++) {
            int idx = i;
            addRenderableWidget(Button.builder(Component.literal((tab == i ? "> " : "   ") + TABS[i]), b -> {
                tab = idx;
                rebuild();
            }).bounds(px + 12, py + 50 + i * 28, 126, 24).build());
        }

        switch (tab) {
            case 0 -> {
                addRenderableWidget(CycleButton.<Quality>builder(q -> Component.literal(q.name()))
                        .withValues(Quality.values()).withInitialValue(ClientConfig.QUALITY.get())
                        .create(c0, y0, colW, 20, Component.literal("Профиль"), (b, v) -> {
                            ClientConfig.QUALITY.set(v);
                            ClientConfig.QUALITY.save();
                        }));
                addRenderableWidget(toggle(c1, y0, colW, "Автокачество", ClientConfig.AUTO_QUALITY));
                addRenderableWidget(new DoubleSlider(c0, y0 + row, colW, "Качество шагов", ClientConfig.STEP_QUALITY, 0.5, 2.0, "%.2f"));
                addRenderableWidget(new IntSlider(c1, y0 + row, colW, "Детальность", ClientConfig.DETAIL, -1, 1, new String[]{"ниже", "обычная", "выше"}));
                addRenderableWidget(new DoubleSlider(c0, y0 + row * 2, colW, "Дальность, блоков", ClientConfig.VIEW_DISTANCE, 500, 8000, "%.0f"));
                addRenderableWidget(toggle(c1, y0 + row * 2, colW, "Тени облаков", ClientConfig.CLOUD_SHADOWS));
                addRenderableWidget(toggle(c0, y0 + row * 3, colW, "Процедурное небо", ClientConfig.CUSTOM_SKY));
                addRenderableWidget(toggle(c1, y0 + row * 3, colW, "Облака в небе", ClientConfig.AMBIENT_CLOUDS));
            }
            case 1 -> {
                addRenderableWidget(new DoubleSlider(c0, y0, colW, "Реалистичность", ClientConfig.REALISM, 0.0, 1.0, "%.2f"));
                addRenderableWidget(new DoubleSlider(c1, y0, colW, "Плотность", ClientConfig.CLOUD_DENSITY, 0.3, 2.5, "%.2f"));
                addRenderableWidget(new DoubleSlider(c0, y0 + row, colW, "Контраст", ClientConfig.CONTRAST, 0.5, 1.8, "%.2f"));
                addRenderableWidget(new DoubleSlider(c1, y0 + row, colW, "Покрытие неба", ClientConfig.COVERAGE, 0.4, 1.6, "%.2f"));
                addRenderableWidget(new DoubleSlider(c0, y0 + row * 2, colW, "Скорость облаков", ClientConfig.CLOUD_SPEED, 0.0, 4.0, "%.2f"));
                addRenderableWidget(new IntSlider(c1, y0 + row * 2, colW, "Вид облаков", ClientConfig.CLOUD_REGIME, -1, 14, REGIMES));
                addRenderableWidget(toggle(c0, y0 + row * 3, colW, "Разные дни", ClientConfig.CLOUD_VARIETY));
                addRenderableWidget(new DoubleSlider(c1, y0 + row * 3, colW, "Темнота под штормом", ClientConfig.STORM_DARKNESS, 0.0, 1.0, "%.2f"));
            }
            case 2 -> {
                addRenderableWidget(toggle(c0, y0, colW, "Штормовые облака", ClientConfig.STORM_CLOUDS));
                addRenderableWidget(toggle(c1, y0, colW, "Обломки у торнадо", ClientConfig.DEBRIS));
                addRenderableWidget(new DoubleSlider(c0, y0 + row, colW, "Толщина воронки", ClientConfig.FUNNEL_SCALE, 0.5, 2.5, "%.2f"));
                addRenderableWidget(new DoubleSlider(c1, y0 + row, colW, "Темнота под штормом", ClientConfig.STORM_DARKNESS, 0.0, 1.0, "%.2f"));
            }
            default -> {
                addRenderableWidget(Button.builder(Component.literal("Открыть радар (K)"),
                        b -> minecraft.setScreen(new RadarScreen())).bounds(c0, y0, colW, 20).build());
                addRenderableWidget(Button.builder(Component.literal("Все параметры..."), b ->
                        net.neoforged.fml.ModList.get().getModContainerById(RealWeather.MODID).ifPresent(
                                c -> minecraft.setScreen(new net.neoforged.neoforge.client.gui.ConfigurationScreen(c, this))))
                        .bounds(c1, y0, colW, 20).build());
            }
        }

        int by = py + ph - 30;
        addRenderableWidget(Button.builder(Component.literal("Лёгкий"), b -> preset(0)).bounds(cx, by, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Баланс"), b -> preset(1)).bounds(cx + 74, by, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Красивый"), b -> preset(2)).bounds(cx + 148, by, 76, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose()).bounds(px + pw - 100, by, 88, 20).build());
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ оформление

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xE0050A12, 0xF00F1A2B);
        g.fill(px - 2, py - 2, px + pw + 2, py + ph + 2, 0xFF1B2B40);
        g.fill(px, py, px + pw, py + ph, 0xFF0B1220);
        g.fillGradient(px, py, px + pw, py + 38, 0xFF16263E, 0xFF0F1A2C);
        g.fill(px, py + 38, px + pw, py + 40, ACCENT);
        g.fill(px + 144, py + 52, px + 145, py + ph - 40, 0xFF1B2B40);
        g.drawString(font, "RealWeather", px + 14, py + 10, 0xFFFFFFFF, false);
        g.drawString(font, "настройки графики и погоды", px + 14, py + 22, 0xFF7F9BC0, false);
        g.drawString(font, TAB_HINTS[tab], px + 152, py + 46, 0xFF9FB6D6, false);
        g.drawString(font, "Изменения применяются сразу и сохраняются в realweather-client.toml", px + 152, py + ph - 46, 0xFF5E7596, false);
        super.render(g, mx, my, pt);
    }
}
